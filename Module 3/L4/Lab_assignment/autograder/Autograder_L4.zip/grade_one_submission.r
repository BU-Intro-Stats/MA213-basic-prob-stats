# load in the package
library(gradeR)

calcGradesForGradescope("Lab4.R",       # each student's submission must be named this!
                        "Lab_answer_test.r") # the file with all of the testthat tests 
  
